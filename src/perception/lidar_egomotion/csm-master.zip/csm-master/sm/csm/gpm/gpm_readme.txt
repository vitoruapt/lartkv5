
This is a stripped-down version of GPM.
It is used here as a first guess to be refined by ICP, so it does not iterate.

Please see the corresponding paper:

	http://purl.org/censi/2006/gpm