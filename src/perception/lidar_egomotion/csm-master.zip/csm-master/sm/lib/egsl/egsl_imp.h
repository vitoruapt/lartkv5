#ifndef H_EGSL_IMP
#define H_EGSL_IMP
#include "egsl.h"

void check_valid_val(val v);
void egsl_error(void);
val egsl_copy_val(val v1);

#endif
