function v = vers(theta)
% returns 2d versor of direction theta
        v = [cos(theta); sin(theta)];

